using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PFMS.API.Data;
using PFMS.API.Models;

namespace PFMS.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public TransactionController(ApplicationDbContext context) => _context = context;

        [HttpGet("{userId}")]
        public async Task<IActionResult> Get(int userId)
        {
            var txns = await _context.Transactions
                .Where(t => t.UserId == userId)
                .ToListAsync();
            return Ok(txns);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Transaction txn)
        {
            _context.Transactions.Add(txn);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { userId = txn.UserId }, txn);
        }
    }
}