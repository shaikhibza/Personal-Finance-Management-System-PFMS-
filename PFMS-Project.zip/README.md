# Personal Finance Management System (PFMS)

## Overview
PFMS is a full-stack web application that allows users to track their income, expenses, and savings.

## Technologies
- C#, ASP.NET Core, MVC
- Angular/React
- Entity Framework Core
- SQL Server
- Azure
- Microservices

## Setup Instructions
1. Clone the repository
2. Setup DB and run `dotnet ef database update`
3. Run the API using `dotnet run` in the PFMS.API directory
4. Run frontend with Angular CLI or React scripts